package graphFramework;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import LSRoutingApp.Path;
import LSRoutingApp.Router;

public class Graph {
	int verticesNo;
	int edgeNo;
	boolean isDigraph = false;
	ArrayList<Vertex> vertices = new ArrayList<Vertex>();

	public Graph() {

	}

	public Graph(int verticesNo, int edgeNo, boolean isDigraph) {
		this.verticesNo = verticesNo;
		this.edgeNo = edgeNo;
		this.isDigraph = isDigraph;

	}

	public void makeGraph() {
		// random class
		Random ran = new Random();

		for (int i = 0; i < verticesNo; i++) {
			vertices.add(new Router(i, "x" + i));
		}

		// check that all vertices are connected
		for (int i = 0; i < verticesNo - 1; i++) {
			int RandomNum = ran.nextInt(10) + 1;
			addEdge(vertices.get(i), vertices.get(i + 1), RandomNum);

		}

		// Remaining edge
		int remaning = edgeNo - (verticesNo - 1);

		for (int i = 0; i < remaning; i++) {
			Vertex source = vertices.get(ran.nextInt(verticesNo));
			Vertex Destination = vertices.get(ran.nextInt(verticesNo));

			int weight = ran.nextInt(20) + 1;
			// to avoid duplicate edges
			if (source == Destination || isConnected(source, Destination)) {
				i--;
			} else {
				// add edge to graph
				addEdge(source, Destination, weight);
			}
		}
		// reset the edgeNo count
		this.edgeNo = remaning + (verticesNo - 1);
	}

	public void readGraphFromFile(String fileName) throws FileNotFoundException {
		File file = new File(fileName);
		Scanner scanner = new Scanner(file);

		this.isDigraph = scanner.nextLine().trim().equalsIgnoreCase("digraph 1");
		this.verticesNo = scanner.nextInt();
		this.vertices = new ArrayList<Vertex>();

		// create all vertices

		int edgeNo = scanner.nextInt();
		int count = 0;
		for (int m = 0; m < edgeNo; m++) {
			Vertex sRouter = getRouterOrCreate(new Router(scanner.next()));
			if (sRouter.label == -1)
				sRouter.label = count++;
			Vertex tRouter = getRouterOrCreate(new Router(scanner.next()));
			if (tRouter.label == -1)
				tRouter.label = count++;
			int EdgeWeight = scanner.nextInt();
			addEdge(sRouter, tRouter, EdgeWeight);
		}
		scanner.close();
	}

	public void addEdge(Vertex source, Vertex target, int weight) {
		Path road = new Path(source, target, weight);
		source.adjlist.addFirst(road);
		if (isDigraph) {
			this.edgeNo += 1;
		} else {
			road = new Path(target, source, weight);
			target.adjlist.addFirst(road);
			this.edgeNo += 2;
		}
	}

	public boolean isConnected(Vertex Source, Vertex target) {
		for (Edge edge : Source.adjlist) {
			if (edge.target == target) {
				return true;
			}
		}
		return false;
	}

	public Vertex getRouterOrCreate(Router searchRouter) {
		for (Vertex vertex : vertices)
			if (vertex.equals(searchRouter)) {
				return vertex;
			}
		vertices.add(searchRouter);
		return vertices.get(vertices.size() - 1);
	}


	public Vertex getVertexByLabel(int label) {
		for (Vertex vertex : vertices)
			if (vertex.label == label) {
				return vertex;
			}
		return null;
	}

}
