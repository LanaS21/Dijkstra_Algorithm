package graphFramework;

import java.util.*;

import LSRoutingApp.Path;
import LSRoutingApp.Router;

public class DijkstraAlg {

	Graph graph;

	public DijkstraAlg(Graph graph) {
		this.graph = graph;

	}

	public void dijkstra(int src) {

		Vertex srcVertex = graph.getVertexByLabel(src);
		String routerName = ((Router) srcVertex).getRouterName();
		// Initialize the resultList
		Path[] result = new Path[graph.verticesNo];
		// fill all edges weight with infinity
		// Note: we will use Label to differentiate between vertices
		for (int i = 0; i < graph.verticesNo; i++)
			result[i] = new Path(srcVertex, graph.getVertexByLabel(i), Integer.MAX_VALUE);

		// set the source-source edge weight to zero
		result[srcVertex.label].weight = 0;

		// keep monitoring the parent of each node
		int[] parents = new int[graph.verticesNo];
		// set the src to point at -1 cause
		parents[src] = -1;

		// Create PriorityQueue to simulate the MinHeap
		PriorityQueue<Edge> pq = new PriorityQueue<>((v1, v2) -> v1.weight - v2.weight);
		// add the source Vertex and start processing
		pq.add(new Edge(srcVertex, srcVertex, 0));

		while (pq.size() > 0) {
			// extract the next minimum weighted edge
			Edge current = pq.poll();
			// get the target vertex Adjlist
			Vertex target = graph.getVertexByLabel(current.target.label);
			for (Edge n : target.adjlist) {
				// get the weight of the new edge (road)
				int newWeight = result[current.target.label].weight + n.weight;
				// check if using this edge/road will is less than the current road to target
				// vertex
				if (newWeight < result[n.target.label].weight) {
					// replace the weight with the newWeight
					result[n.target.label].weight = newWeight;
					parents[n.target.label] = target.label;
					// add the new road to the PriorityQueue to be processed later
					pq.add(new Edge(srcVertex, n.target, newWeight));
				}
			}
		}

		System.out.println("The source router is " + routerName);
		System.out.println("The paths from router " + routerName + " to the rest of the routers are:");

		for (int i = 0; i < graph.verticesNo; i++) {
			// Skip the src Vertex
			if (src == i)
				continue;

			printPath(parents[i], parents);
			System.out.println(graph.getVertexByLabel(i) + " route length: " + result[i].weight);
		}
	}

	private void printPath(int currentVertex, int[] parents) {

		if (currentVertex == -1) {
			return;
		}
		printPath(parents[currentVertex], parents);
		System.out.print(graph.getVertexByLabel(currentVertex) + " - ");
	}

}
