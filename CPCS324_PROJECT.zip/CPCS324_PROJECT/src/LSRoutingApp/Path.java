/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LSRoutingApp;

import graphFramework.Edge;
import graphFramework.Vertex;

/**
 *
 * @author Lan
 */
public class Path extends Edge {
	int roadSize;

	public Path(Vertex source, Vertex target, int weight) {
		super(source, target, weight);
		roadSize = weight * 3;
	}

	public Path() {

	}

	public void displayInfo() {
		System.out.println(source + " - " + target + " route length: " + weight);
	}

}
